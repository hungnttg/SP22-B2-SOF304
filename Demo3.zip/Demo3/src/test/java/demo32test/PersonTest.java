package demo32test;

import static org.junit.Assert.fail;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import demo32.Person;

public class PersonTest {
	Person p;
	//1: Lap trinh vien da chi ra ngoai le
	//Nhiem vu cua tester la kiem tra xem lap trinh vien dua ngoai le dung khong?
	@Test(expected = IllegalArgumentException.class)
	public void testLoai2_ExpectedException()
	{
		p = new Person("NguyenVanA", -1);
	}
	//-------------------------
	//2: tester tu de xuat exception phu hop
	@Rule
	public ExpectedException exception = ExpectedException.none();
	@Test
	public void testExpectedException()
	{
		exception.expect(IllegalArgumentException.class);
		p = new Person("TranVanB",-2);
	}
	//3. Su dung try....catch
	@Test
	public void testTryCatchException()
	{
		try {
			p = new Person("VuVanC",-3);
			fail("Nen co ngoai le la IllegalArgumentException vi tuoi la so am");
		}
		catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
	
}
