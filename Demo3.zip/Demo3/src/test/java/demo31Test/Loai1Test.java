package demo31Test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import demo31.Loai1;


public class Loai1Test {
	String msg = "Hung";
	Loai1 l1 = new Loai1(msg);
	//th1: Lap trinh vien khong dua ra ngoai le cu the
	//tester phai doan duoc ngoai le va yeu cau lap trinh vien sua lai cho dung ngoai le
	@Test(expected = ArithmeticException.class )
	public void testPrintMessage() throws Exception
	{
		System.out.println("Thong bao cua ham PrintMessage");
		l1.printMesage();	
	}
	@Test
	public void testHiPrintMessage() throws Exception
	{
		System.out.println("Thong bao cua ham printHiMessage");
		msg = "Hi!"+msg;
		//l1.printHiMessage();
		assertEquals(msg, l1.printHiMessage());
	}
}
