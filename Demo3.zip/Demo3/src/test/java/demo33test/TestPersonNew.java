package demo33test;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;


public class TestPersonNew {
	@Rule
	public ErrorCollector collector = new ErrorCollector();
	@Test
	public void example()
	{
		collector.addError(new Throwable("Loi dong dau tien"));
		collector.addError(new Throwable("Lo dong thu 2"));
		System.out.println("Hello");
		try {
			Assert.assertTrue("A"=="A");
		} catch (Exception e) {
			collector.addError(e);
		}
		System.out.println("World...");
	}
}
