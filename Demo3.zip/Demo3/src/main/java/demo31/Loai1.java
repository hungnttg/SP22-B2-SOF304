package demo31;

public class Loai1 {
	private String message;
	public Loai1(String message)
	{
		this.message = message;
	}
	public void printMesage()
	{
		System.out.println(message);
		int divide = 1/0;
	}
	public String printHiMessage()
	{
		message = "Hi!"+message;
		System.out.println(message);
		return message;
	}
}
