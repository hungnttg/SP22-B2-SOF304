package demo53;

import org.testng.annotations.Test;

public class Demo53Group {
	@Test(groups = "G1")
	public void test1()
	{
		System.out.println("Day la test1 trong group G1");
	}
	@Test(groups = "G1")
	public void test2()
	{
		System.out.println("Day la test2 trong group G1");
	}
	@Test(groups = "G2")
	public void test3()
	{
		System.out.println("Day la test3 trong group G2");
	}
	@Test(groups = "G2")
	public void test4()
	{
		System.out.println("Day la test4 trong group G2");
	}
	
	
	
	
}
