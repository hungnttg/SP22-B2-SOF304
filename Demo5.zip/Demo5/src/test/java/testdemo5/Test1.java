package testdemo5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1 {
	
	@Test
	public void test11()
	{
		//Tham chiếu đến chromedriver
		System.setProperty("webdriver.chrome.driver", 
				"/Users/macos/Desktop/Demo_SP22_B2/WorkspaceEclipse/chromedriver");
		WebDriver driver = new ChromeDriver();//tao driver de test
		String url = "https://lms.poly.edu.vn/";//web can test
		String title_expect = "AAA";
		String title_result = "";
		driver.get(url);//dua duong dan vao driver
		title_result = driver.getTitle();//lay title qua driver
		if(title_expect.equals(title_result))
		{
			System.out.println("testcase passed");
		}
		else
		{
			System.out.println("Testcase faile");
		}
		driver.close();
		Assert.assertEquals(title_expect, title_expect);
	}
}
