package demo52;

import org.testng.annotations.Test;

public class Test52 {
	@Test
	public void testcase1()
	{
		System.out.println("day la test case 1");
	}
	@Test
	public void testcase2()
	{
		System.out.println("day la test case 2");
	}
	@Test
	public void testcase3()
	{
		System.out.println("day la test case 3");
	}
}
