package demo52;

import org.testng.annotations.Test;

public class Test522 {
	@Test
	public void testcase4()
	{
		System.out.println("day la test case 4");
	}
	@Test
	public void testcase5()
	{
		System.out.println("day la test case 5");
	}
	@Test
	public void testcas6()
	{
		System.out.println("day la test case 6");
	}
	@Test
	public void testcase7()
	{
		System.out.println("day la test case 7");
	}
}
