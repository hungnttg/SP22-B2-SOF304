﻿using System;
namespace Demo22
{
    public class BankAccount
    {
        private readonly string m_customerName;//ten khach hang
        private double m_banlance;
        private BankAccount()
        {
        }
        public BankAccount(string customerName,double balance)
        {
            m_customerName = customerName;
            m_banlance = balance;
        }
        public string CustomerName
        {
            get { return m_customerName; }
        }
        public double Banlance
        {
            get { return m_banlance; }
        }
        public void Debit(double amount)//tao ham tai khoan Debit
        {
            if (amount > m_banlance)//rut tien lon hon tien trong tai khoan
            {
                throw new Exception("amount");
            }
            if (amount < 0)//so tien nho hon 0
            {
                throw new Exception("amount");
            }
            m_banlance -= amount;//cho sua sai
        }
        public void Credit(double amount)
        {
            if (amount < 0)
            {
                throw new Exception("amount");
            }
            m_banlance += amount;
        }
    }
}
