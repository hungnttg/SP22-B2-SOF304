﻿using System;

namespace Demo22
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount ba = new BankAccount("Hung", 11.99);
            ba.Credit(5.67);
            ba.Debit(11.11);
            Console.WriteLine("So du hien tai: ${0}", ba.Banlance);
        }
    }
}
