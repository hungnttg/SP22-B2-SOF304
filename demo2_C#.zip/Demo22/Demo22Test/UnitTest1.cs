﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Demo22;
namespace Demo22Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
        [TestMethod]
        public void Debit_SoTienHopLe_CapNhatSoDu()
        {
            double beginningBalance = 11.99;//tong so du
            double debitAmount = 4.55;//so tien debit
            double expected = 7.44;//so tien con lai
            BankAccount account = new BankAccount("Cuong", beginningBalance);

            account.Debit(debitAmount);//hanh dong rut tien
            //Assert
            double actual = account.Banlance;
            Assert.AreEqual(expected, actual, 0.001, "Tai khoan debit khong hop le");
        }
    }
}
