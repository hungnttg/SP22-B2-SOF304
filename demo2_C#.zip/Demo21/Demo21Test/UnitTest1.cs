﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System;
//MSTest Project
//Trên Window: Nhân Ctrl + T hoặc Ctrl+ E (hiển thị dự án)
//Chạy test: Ctrl + R, V
namespace Demo21Test
{
    [TestClass]
    public class UnitTest1
    {
        private const string Expected = "Hello World!";
        [TestMethod]
        public void TestMethod1()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                Demo21.Program.Main();//tham chieu den ham main cua lap trinh vien
                var result = sw.ToString().Trim();
                Assert.AreEqual(Expected,result);
            }
        }
    }
}
