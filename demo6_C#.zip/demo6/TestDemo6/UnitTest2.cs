﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace TestDemo6
{
    public class UnitTest2
    {
        //Test click vao link su dung XPath
        IWebDriver driver;
        [Test]
        public void testcase2()
        {
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Url = "https://demo.guru99.com/test/guru99home/";
            driver.Manage().Window.Maximize();
            IWebElement link = driver
                .FindElement(By.XPath("/html/body/div[3]/div[2]/nav/div/div/ul/li[5]/a"));
            link.Click();
            driver.Close();
        }
    }
}
