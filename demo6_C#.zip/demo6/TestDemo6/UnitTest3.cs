﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace TestDemo6
{
    public class UnitTest3
    {
        //Nhap lieu vao TextBox va click vao Sign up button
        IWebDriver driver;
        [Test]
        public void testcase3()
        {
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Url = "https://demo.guru99.com/test/guru99home/";
            driver.Manage().Window.Maximize();
            IWebElement emaitTextBox = driver.FindElement(By.XPath("/html/body/div[4]/section/div[2]/div/div[3]/div/div/div[1]/div/div/div/article/form/input"));
            IWebElement signupButton = driver.FindElement(By.XPath("/html/body/div[4]/section/div[2]/div/div[3]/div/div/div[1]/div/div/div/article/form/button"));
            emaitTextBox.SendKeys("test123@gmail.com");//nhap lieu
            signupButton.Click();
            driver.Close();
        }
    }
}
