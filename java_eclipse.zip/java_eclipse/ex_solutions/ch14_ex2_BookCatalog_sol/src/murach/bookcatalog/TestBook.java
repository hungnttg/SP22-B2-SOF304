package murach.bookcatalog;

public interface TestBook {
    boolean test(Book b);
}
