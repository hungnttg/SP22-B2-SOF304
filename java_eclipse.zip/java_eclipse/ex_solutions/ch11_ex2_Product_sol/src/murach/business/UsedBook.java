package murach.business;

public class UsedBook extends Book {

    @Override
    public String getDisplayText() {
        return "";
    }

}
