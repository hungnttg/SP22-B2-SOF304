package murach.test;

public interface Displayable {
    String getDisplayText();
}
