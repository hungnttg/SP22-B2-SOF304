package murach;

import murach.ui.AreaAndPerimeterFrame;

public class Main {

    public static void main(String[] args) {
        new AreaAndPerimeterFrame();
    }
    
}
