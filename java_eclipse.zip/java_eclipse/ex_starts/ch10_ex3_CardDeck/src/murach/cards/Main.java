package murach.cards;

public class Main {

    public static void main(String[] args) {
        loadCardArray();
        printCardArray();
        shuffleCards();
        printCardArray();
        dealCards();
        showCards();
    }

    private static void loadCardArray() {
        // load cards here        
    }

    private static void printCardArray() {
        // print cards to console here
    }

    private static void shuffleCards() {
        // shuffle cards here
    }

    private static void dealCards() {
        // deal cards here
    }

    private static void showCards() {
        // show the cards that were dealt here
    }
}