package murach.test;

import java.io.*;

public class CustomTesterApp {

    public static void main(String[] args) {
        Method1();
    }

    public static void Method1() {
        Method2();
    }

    public static void Method2() {
        Method3();
    }

    public static void Method3() {
        //Add code to throw an exception here.
    }
}
