package murach;

import murach.ui.ProductManagerFrame;

public class Main {

    @SuppressWarnings("unused")
	public static void main(String[] args) {
        ProductManagerFrame frame = new ProductManagerFrame();
    }
}