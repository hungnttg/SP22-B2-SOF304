﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace TestDemo6
{
    public class UnitTest73
    {
        IWebDriver driver;
        [Test]
        public void testcase733()
        {
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Url = "https://www.google.com/";
            driver.Manage().Window.Maximize();
            Thread.Sleep(2000);
            IWebElement el = driver.FindElement(By.Name("q"));
            el.SendKeys("kiem thu phan mem");
            Thread.Sleep(2000);
            IWebElement btn = driver.FindElement(By.Name("btnK"));
            btn.Click();
            
            driver.Close();
        }
    }
}
