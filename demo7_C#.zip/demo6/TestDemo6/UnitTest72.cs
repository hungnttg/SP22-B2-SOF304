﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace TestDemo6
{
    public class UnitTest72
    {
        //Chon 1 gia tri cua Combobox (dropdown)
        IWebDriver driver;
        [Test]
        public void testcase722()
        {
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Url = "https://demo.guru99.com/test/guru99home/";
            driver.Manage().Window.Maximize();
            IWebElement drop
                = driver.FindElement(By.XPath(".//*[@id='awf_field-91977689']"));
            var selectObj = new SelectElement(drop);
            selectObj.SelectByValue("sap-abap");
            driver.Close();
        }
    }
}
