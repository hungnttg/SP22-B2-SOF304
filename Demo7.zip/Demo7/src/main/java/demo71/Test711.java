package demo71;

import org.testng.annotations.Test;

public class Test711 {
	@Test
	public void fun1()
	{
		System.out.println("test func1");
	}
	@Test
	public void fun2()
	{
		System.out.println("test func2");
	}
	@Test
	public void fun3()
	{
		System.out.println("test func3");
	}

}
