package demo71;

import org.testng.annotations.Test;

public class Test713 {
	@Test
	public void fun6()
	{
		System.out.println("test func6 of test3");
	}
	@Test
	public void fun7()
	{
		System.out.println("test func7 of test 3");
	}
}
