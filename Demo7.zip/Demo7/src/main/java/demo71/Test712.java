package demo71;

import org.testng.annotations.Test;

public class Test712 {
	@Test
	public void fun4()
	{
		System.out.println("test func4");
	}
	@Test
	public void fun5()
	{
		System.out.println("test func5");
	}
	@Test
	public void fun6()
	{
		System.out.println("test func6 of test2");
	}
	@Test
	public void fun7()
	{
		System.out.println("test func7 of test 2");
	}
}
