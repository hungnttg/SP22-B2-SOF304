package demo73;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Demo731 {
	//kéo thả
	@Test
	public void testcase52()
	{
		//Tham chiếu đến driver
		System.setProperty("webdriver.chrome.driver", 
				"/Users/macos/Desktop/Demo_SP22_B2/WorkspaceEclipse/chromedriver");
		WebDriver driver = new ChromeDriver();//tao doi tuong driver
		String url = "http://demo.guru99.com/test/drag_drop.html";
		driver.get(url);//truy cap vao url
		//lay thanh phan webElement can keo (Bank)
		WebElement from =  driver.findElement(By.xpath("//*[@id=\"credit2\"]/a"));	
		Actions act = new Actions(driver);
		act.dragAndDropBy(from, 135, 40).build().perform();//keo den vi tri mong muon
		//ket thuc
		driver.close();
	}
}
