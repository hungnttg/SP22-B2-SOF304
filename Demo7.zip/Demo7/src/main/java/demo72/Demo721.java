package demo72;

import java.awt.TextField;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import zmq.io.net.Address;

public class Demo721 {
	//login tu dong voi testng va selenium
	@Test
	public void testcase51()
	{
		//Tham chiếu đến driver
		System.setProperty("webdriver.chrome.driver", 
				"/Users/macos/Desktop/Demo_SP22_B2/WorkspaceEclipse/chromedriver");
		WebDriver driver = new ChromeDriver();//tao doi tuong driver
		String url = "http://demo.guru99.com/test/login.html";
		driver.get(url);//truy cap vao url
		//lay thanh phan webElement
		WebElement email = driver.findElement(By.id("email"));
		WebElement password = driver.findElement(By.id("passwd"));
		//gui email vao thanh phan email
		email.sendKeys("abc@gmail.com");
		//gui password vao thanh phan password
		password.sendKeys("abcdefgh");
		System.out.println("Text field set");
		//xoa gia tri trong TextBox
		email.clear();
		password.clear();
		System.out.println("Da xoa du lieu trong textbox");
		//tim button de gui du lieu di
		WebElement login = driver.findElement(By.id("SubmitLogin"));
		//su dung phuong thuc submit form
		email.sendKeys("abc@gmail.com");
		password.sendKeys("abcdefgh");
		login.click();//click tu dong vao button
		System.out.println("Da click vao button");
		//submit
		driver.get(url);
		driver.findElement(By.id("email")).sendKeys("abc@gmail.com");
		driver.findElement(By.id("passwd")).sendKeys("abc123456");
		driver.findElement(By.id("SubmitLogin")).submit();
		System.out.println("Da submit");
		//ket thuc
		driver.close();
	}
}
