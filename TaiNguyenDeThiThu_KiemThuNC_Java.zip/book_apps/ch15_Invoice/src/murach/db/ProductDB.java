package murach.db;

import murach.business.Product;


public class ProductDB {

    public static Product getProduct(String productCode) {
        // In a more realistic application, this code would
        // get the data for the product from a file or database
        // For now, this code just uses if/else statements
        // to return the correct product

        // create the Product object
        Product product = new Product();

        // fill the Product object with data
        product.setCode(productCode);
        if (productCode.equalsIgnoreCase("aa")) {
            product.setDescription("aa");
            product.setPrice(57.50);
        } else if (productCode.equalsIgnoreCase("bb")) {
            product.setDescription("cc");
            product.setPrice(57.50);
        } else if (productCode.equalsIgnoreCase("dd")) {
            product.setDescription("dd");
            product.setPrice(54.50);
        } else {
            product.setDescription("Unknown");
        }
        return product;
    }
}