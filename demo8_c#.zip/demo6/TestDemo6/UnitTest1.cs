﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace TestDemo6
{
    public class Tests
    {
        
        ChromeDriver driver;//khai bao driver
        [SetUp]
        public void Setup()
        {
            //khoi tao driver
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Manage().Window.Maximize();//quan tri toi da cac cua so 
        }

        [Test]
        public void Testcase1()
        {
            driver.Url = "https://lms.poly.edu.vn/";
            string expect_title = "Learning Management System | Hệ thống quản trị học tập | FPT Polytechnic Việt Nam";
            string actual_tile = driver.Title;
            Assert.AreEqual(expect_title, actual_tile);
        }
        [TearDown]
        public void teardown()
        {
            driver.Close();
        }
       
    }
}