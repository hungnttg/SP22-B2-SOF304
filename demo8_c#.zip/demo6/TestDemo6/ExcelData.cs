﻿using System;
using System.Collections.Generic;
using System.Text;
using ExcelDataReader;
using OpenQA.Selenium;
using System.IO;
using System.Data;
using System.Linq;

namespace TestDemo6
{
    public class ExcelData
    {
        //1. Tao collection de luu tru du lieu
        private static List<DataCollection> dataCollection = new List<DataCollection>();
        //2. tao ham dua du lieu vao collection
        public static void PolulataInCollection(string ExcelFileName)
        {
            DataTable table = ExcelToDataTable(ExcelFileName);
            //tham chieu den cac dong, cac cot
            for (int row = 1; row <= table.Rows.Count; row++)
            {
                for (int col = 0; col < table.Columns.Count; col++)
                {
                    DataCollection dtTable = new DataCollection()
                    {
                        //dien du lieu tu file excel vao dtTable
                        RowNumber = row,
                        ColumnName = table.Columns[col].ColumnName,
                        ColumnValue = table.Rows[row - 1][col].ToString()
                    };
                    dataCollection.Add(dtTable);//dua vao dataTable
                }
            }
        }
        public static string ReadData(int rowNumber, string ColumnName)
        {
            try
            {
                //lay du lieu bang cach dung linq
                string data = (from colData in dataCollection
                               where colData.ColumnName == ColumnName
                               && colData.RowNumber == rowNumber
                               select colData.ColumnValue).SingleOrDefault();
                return data.ToString();
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public static DataTable ExcelToDataTable(String ExcelFileName)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            //1.doc file
            using (FileStream stream = File.Open(ExcelFileName, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (data) => new ExcelDataTableConfiguration()
                        { 
                            UseHeaderRow = true
                        }
                    });
                    //2.lay tat ca cac table
                    DataTableCollection table = result.Tables;
                    //3.luu tru trong datatable
                    DataTable resultTable = table["Sheet1"];
                    return resultTable;
                }
            }
        }
    }
    public class DataCollection
    {
        public int RowNumber { get; set; }
        public string ColumnName { get; set; }
        public string ColumnValue { get; set; }
    }
}
