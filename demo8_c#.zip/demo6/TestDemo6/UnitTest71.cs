﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;


namespace TestDemo6
{
    public class UnitTest71
    {
        //nhap du lieu vao TextBox, click button (su dung css)
        IWebDriver driver;
        [Test]
        public void testcase3()
        {
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Url = "https://demo.guru99.com/test/guru99home/";
            driver.Manage().Window.Maximize();
            IWebElement emailTextBox
            = driver.FindElement(By.CssSelector("#philadelphia-field-email"));//phai chuot copy selector
            IWebElement signUpButton
                = driver.FindElement(By.CssSelector("#philadelphia-field-submit"));
            emailTextBox.SendKeys("test111@gmail.com");
            try{
                signUpButton.Click();
                IAlert alt = driver.SwitchTo().Alert();
                alt.Accept();
            }catch (NoAlertPresentException e){ 
                
            }   
            driver.Close();
        }
    }
}
