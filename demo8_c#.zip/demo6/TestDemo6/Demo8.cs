﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;


namespace TestDemo6
{
 
    public class Demo8
    {
        IWebDriver driver;
        [Test]
        public void testcase81()
        {
            driver = new ChromeDriver("C:\\Users\\nguye\\Downloads\\chromedriver_win32");
            driver.Url = "http://hn-lms.poly.edu.vn/login.php?target=&client_id=lmsfpoly&auth_stat=";
            driver.Manage().Window.Maximize();
            
            //Thread.Sleep(2000);
            Sign_Up_Page.ClearLoginInfomation(driver);
            string fileName = Environment.CurrentDirectory.ToString() +
                "\\ExcelDataFile\\SeleniumTraining.xlsx";
            ExcelData.PolulataInCollection(fileName);
            Sign_Up_Page.LoginInfomation(ExcelData.ReadData(1,"UserEmail"),
                ExcelData.ReadData(1,"Password"),driver);

            //Thread.Sleep(2000);
            IWebElement btn = driver.FindElement(By.
                CssSelector("#form_ > div > div.ilFormFooter.clearfix > div.col-sm-6.ilFormCmds > input"));
            btn.Click();
            //Assert.AreEqual("Double check your email and try again",
            //    driver.FindElement(By.Id("siteMembersInputErrorMessage_emailInput_SM_ROOT_COMP11")).Text);
            driver.Close();

        }
    }
}
