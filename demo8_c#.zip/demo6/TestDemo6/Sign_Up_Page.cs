﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestDemo6
{
    class Sign_Up_Page
    {
        public static void ClearLoginInfomation(IWebDriver Driver)
        {
            Driver.FindElement(By.Id("username")).Clear();
            Driver.FindElement(By.Id("password")).Clear();
        }
        public static void LoginInfomation(string UserEmail, string password, IWebDriver Driver)
        {
            Driver.FindElement(By.Id("username")).SendKeys(UserEmail);
            Driver.FindElement(By.Id("password")).SendKeys(password);
        }

     

    }
}
