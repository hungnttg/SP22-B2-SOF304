package test8;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Test82 {
	@Test
	public void test82()//chon Combobox
	{
		//Tham chiếu đến chromedriver
		System.setProperty("webdriver.chrome.driver", 
				"/Users/macos/Desktop/Demo_SP22_B2/WorkspaceEclipse/chromedriver");
		WebDriver driver = new ChromeDriver();//tao driver de test
		String url = "https://demo.guru99.com/test/guru99home/";//web can test	
		driver.get(url);//dua duong dan vao driver
		//truy xuat thanh phan html tren web
		WebElement combobox
		=driver.findElement(By.xpath("//*[@id=\"awf_field-91977689\"]"));
		Select obj= new Select(combobox);
		obj.selectByValue("sap-abap");
		//driver.close();
		
	}
}
