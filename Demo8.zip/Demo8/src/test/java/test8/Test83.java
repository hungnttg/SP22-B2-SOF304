package test8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Test83 {
	@Test
	public void test83()//tim kiem tren google
	{
		//Tham chiếu đến chromedriver
		System.setProperty("webdriver.chrome.driver", 
				"/Users/macos/Desktop/Demo_SP22_B2/WorkspaceEclipse/chromedriver");
		WebDriver driver = new ChromeDriver();//tao driver de test
		String url = "https://www.google.com/";//web can test	
		driver.get(url);//dua duong dan vao driver
		driver.manage().window().maximize();
		//truy xuat thanh phan html tren web
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement el = driver.findElement(By.name("q"));
		el.sendKeys("cach kiem thu phan mem");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement btn = driver.findElement(By.name("btnK"));
		btn.click();
		//driver.close();
		
	}
}
