package test8;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Test84 {
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	Map<String, Object> TestResultNG;
	@BeforeClass
	public void setup()
	{
		workbook = new HSSFWorkbook();
		sheet = workbook.createSheet("Ket qua test");
		TestResultNG = new HashMap<String,Object>();
		TestResultNG.put("1", new Object[] 
				{"Cac buoc test","Ket qua test","De xuat","Thuc te"});
		
	}
	@Test
	public void testchucnang1()
	{
		System.out.println("Test ham 1");
		TestResultNG.put("2", new Object[] 
				{"Thuc hien login","Nhap dung user, pass","True","True"});
	}
	@Test
	public void testchucnang2()
	{
		System.out.println("Test ham 1");
		TestResultNG.put("3", new Object[] 
				{"Thuc hien login","Nhap sai user, pass","True","False"});
	}
	@AfterClass
	public void tearDown()
	{
		Set<String> keyset = TestResultNG.keySet();
		int rownum=0;
		for(String key: keyset)
		{
			Row row = sheet.createRow(rownum++);
			Object[] objArr = (Object[]) TestResultNG.get(key);
			int cellnum=0;
			for(Object obj: objArr)
			{
				Cell cell = row.createCell(cellnum++);
				if(obj instanceof Date)
				{
					cell.setCellValue((java.util.Date)obj);
				}
				else if(obj instanceof Boolean)
				{
					cell.setCellValue((Boolean)obj);
				}
				else if(obj instanceof String)
				{
					cell.setCellValue((String)obj);
				}
				else if(obj instanceof Double)
				{
					cell.setCellValue((Double)obj);
				}
			}
			try {
				FileOutputStream out = 
						new FileOutputStream(new File("kiemthu1.xls"));
				workbook.write(out);
				out.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
