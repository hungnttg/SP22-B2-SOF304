﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo4
{
    public class MessageUtil
    {
        private string Message;
        public MessageUtil(string str)
        {
            this.Message = str;
        }
        public float Divide(float a, float b)
        {
            float result = a / b;
            return result;
        }
        public float Divide1(float a, float b)
        {
            if (b == 0)
            {
                throw new DivideByZeroException("loi chia cho 0");
            }
            float result = a / b;
            return result;
        }
        public int sum(int a, int b)
        {
            return a + b;
        }
    }
}
