package demo63;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class Test3 {
	@Parameters({"para"})
	@Test
	public void testPara(String para)
	{
		System.out.println("Tham so truyen vao la: "+para);
	}
}
