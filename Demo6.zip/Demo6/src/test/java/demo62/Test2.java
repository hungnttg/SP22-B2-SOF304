package demo62;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Test2 {
	//thứ tự chạy của các annotation
	@BeforeClass
	public void beforeClassTest()
	{
		System.out.println("Before Class");
	}
	@Test
	public void testClass()
	{
		System.out.println("Test Class");
	}
	@AfterClass
	public void afterClassTest()
	{
		System.out.println("After Class");
	}
	@BeforeMethod
	public void beforeMethodTest()
	{
		System.out.println("Before Method");
	}
	@Test
	public void testMethod()
	{
		System.out.println("Test Method");
	}
	@AfterMethod
	public void afterTestMethod()
	{
		System.out.println("After Test Method");
	}
}
