using NUnit.Framework;
using FinancialCalculations;
using System;
namespace TestFinancial
{
    //------------------------------phan vung test case-----
    //Hop le: [500->1000000]
    //Khong hop le:
        //So nguyen:
            //Nho hon 500
            // Lon hon 1 trieu
        //Khong phai so nguyen
            //so thuc
            //ky tu chu
            //ky tu dac biet  
    // ----------------------------
    //Ta can chay cac test case sau
    //801 -> valie
    //400-> invalid
    //1000091 -> invalid
    //800.5 -> invalid
    //400.5 -> invalid
    //b -> invalid
    //; -> invalid
    //----------------------------------test case vung bien-----
    //499-> invalid
    //500->valid
    //501->valid
    //999999 ->valid
    //1000000->valid
    //1000001->invalid
    //-----------------------------------xay dung bang quyet dinh test ra file excel--

    public class Tests
    {
        frmDepreciation frm;
        [SetUp]
        public void Setup()
        {
            frm = new frmDepreciation();//tao moi doi tuong form
            //them su kien
            frm.cboLife.SelectedIndexChanged +=
                new System.EventHandler(frm.cboLife_SelectedIndexChanged);
        }

        [Test]
        public void Testcase1()
        {
            
            frm.txtInitialCost.Text = "801";//gan gia tri cho o 1
            frm.txtFinalValue.Text = "10";//gan gia tri cho o 2
            //goi su kien qua delegate
            frm.cboLife_SelectedIndexChanged(this, EventArgs.Empty);
            //chon gia tri
            frm.cboLife.SelectedIndex = 0;//chon item dau tien
            frm.btnCalculate_Click(null, null);//goi su kien btnCalculate_Click
        }
    }
}