package demo11;
//file cua lap trinh vien
public class SoChan {
	public boolean isSoChan(int input)
	{
		if(input%2==0)
		{
			return true;
		}
		return false;
	}
}	
