package demo11;
//file của lập trình viên
public class MessageUtil {
	private String message;
	public MessageUtil(String msg)
	{
		this.message = msg;
	}
	public String printMessage()
	{
		System.out.println(this.message);
		return this.message;
	}

}
