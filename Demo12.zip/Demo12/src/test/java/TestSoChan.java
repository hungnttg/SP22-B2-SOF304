import static org.junit.Assert.assertTrue;

import org.junit.Test;

import demo11.SoChan;

//file cua Test
public class TestSoChan {
	
	@Test
	public void testSoChan()
	{
		int so1 = 5;
		int so2 = 6;
		SoChan soChan = new SoChan();
		boolean result = soChan.isSoChan(so1);
		assertTrue(result);//goi ket qua tra ve
	}
}
