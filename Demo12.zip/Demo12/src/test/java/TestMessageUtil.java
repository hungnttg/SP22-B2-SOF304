import static org.junit.Assert.assertEquals;

import org.junit.Test;

import demo11.MessageUtil;

//file của tester
public class TestMessageUtil {
	String message = "Heelo world";
	MessageUtil messageUtil = new MessageUtil(message);
	@Test
	public void testprintMessage()
	{
		//assertEquals(GiaTriKyVong,GiaTriThucTe)
		assertEquals(message, messageUtil.printMessage());
	}
	
}
