package demo41;

public class Cal {
	public double getVat(double amount)
	{
		return amount*0.1;
	}
}
