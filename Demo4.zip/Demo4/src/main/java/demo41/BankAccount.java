package demo41;

public class BankAccount {
	private String m_customerName;//ten
	private double m_balance;//so du
	public BankAccount(String name,double balance)
	{
		this.m_customerName = name;
		this.m_balance = balance;
	}
	public String getM_customerName() {
		return m_customerName;
	}
	public void setM_customerName(String m_customerName) {
		this.m_customerName = m_customerName;
	}
	public double getM_balance() {
		return m_balance;
	}
	public void setM_balance(double m_balance) {
		this.m_balance = m_balance;
	}
	//rut tien
	public void debit(double amount) throws Exception
	{
		if(amount>m_balance)
		{
			throw new Exception("So tien rut lon hon so du");
		}
		m_balance -= amount;//tru tien khi rut tien
	}
	//nap tien
	public void credit(double amount) throws Exception
	{
		if(amount<0)
		{
			throw new Exception("So tien trong tai khoan <=0");
		}
		m_balance+= amount;//nap tien thi cong vao so du
	}

}
