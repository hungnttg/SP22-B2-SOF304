package demo41test;

import org.testng.Assert;
import org.testng.annotations.Test;

import demo41.BankAccount;

public class TestBankAccount {
	@Test
	public void testcase1_debit() throws Exception
	{
		double beginBalance = 11.99;
		double debitAmount = 4.55;
		double expected = 7.44;
		//tao tai khoan voi so du ban dau
		BankAccount b = new BankAccount("Hung", beginBalance);
		b.debit(debitAmount);//rut tien
		double actual = b.getM_balance();//lay gia tri thuc
		Assert.assertEquals(actual, expected);//test gia tri dung
		Assert.assertNotEquals(b.getM_balance()+1, expected);//test gia tri sai
	}

}
