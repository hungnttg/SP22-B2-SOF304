package demo41test;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import demo41.Calculator;

public class TestCalculator {
	Calculator c1;
	@BeforeTest
	public void setup()
	{
		c1 = new Calculator();//khoi tao gia tri
	}
	@AfterTest
	public void teardown()//huy doi tuong
	{
		c1=null;
	}
	@Test
	public void testcase1_add()
	{
		int expect = 5;
		Assert.assertEquals(c1.add(2, 3), expect);//test gia tri dung
		Assert.assertNotEquals(c1.add(2, 2), expect);//test gia tri sai
		
	}
	@Test
	public void testcase2_subtract()
	{
		int expect = 5;
		Assert.assertEquals(c1.subtract(7, 2), expect);//test gia tri dung
		Assert.assertNotEquals(c1.subtract(7, 3), expect);//test gia tri sai
		
	}

}
