package demo41test;

import org.testng.Assert;
import org.testng.annotations.Test;

import demo41.Cal;

public class TestCal {
	@Test
	public void testCase1_getVat()
	{
		Cal c = new Cal();
		double expect  = 10;//gia tri de xuat
		Assert.assertEquals(c.getVat(100), expect);//chay theo gia tri dung
		Assert.assertNotEquals(c.getVat(120), expect);//chay theo gia tri sai
	}
}
