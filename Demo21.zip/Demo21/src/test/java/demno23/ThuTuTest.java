package demno23;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class ThuTuTest {
	private static ArrayList<String> list;
	@BeforeClass
	public static void m1()
	{
		System.out.println("BeforeClass thuc thi TRUOC TAT CA cac test case");
	}
	@Before
	public static void m2()
	{
		list = new ArrayList<String>();
		System.out.println("Before thuc thi TRUOC MOI test case");
	}
	@AfterClass
	public static void m3()
	{
		System.out.println("Afterclass thuc thi SAU TAT CA cac test case");
	}
	@After
	public static void m4()
	{
		System.out.println("After thuc thi SAU MOI cac test case");
	}
	@Test
	public static void m5()
	{
		 list.add("test");
		 assertFalse(list.isEmpty());
		 assertEquals(1, list.size());
	}
	@Ignore
	public static void m6()
	{
		System.out.println("Ignore: bo qua");
	}
	
	
}
