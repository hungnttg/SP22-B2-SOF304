package demo22test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//dinh nghia cac file can chay gop 1 lan
@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestJunit1.class,
	TestJunit2.class
})
public class TestSuite {
	
	
}
