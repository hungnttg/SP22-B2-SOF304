package demo22test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import demo22.MessageUtil;

public class TestJunit2 {
	String message = "Hung";
	MessageUtil messageUtil = new MessageUtil(message);
	@Test
	public void testPrintMessage()
	{
		System.out.println("Trong ham testHiMessage");
		message = "Hi!"+"Hung";
		assertEquals(message, messageUtil.hiMessage());
	}
}
