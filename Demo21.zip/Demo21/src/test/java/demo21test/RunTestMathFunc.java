package demo21test;

import org.junit.runner.JUnitCore;

public class RunTestMathFunc {
	public static void main(String[] args) {
		JUnitCore runner = new JUnitCore();
		org.junit.runner.Result result = runner.run(TestMathFunc.class);//TestMathFunc: class can chay
		System.out.println("run tests: "+result.getRunCount());//tong so test case chay
		System.out.println("faile tests: "+result.getFailureCount());//tong so test case loi
		System.out.println("ignore tests: "+result.getIgnoreCount());//tong so test case bo qua
		System.out.println("success tests: "+result.wasSuccessful());//ket qua cuoi cung: true, false
		
	}
}
