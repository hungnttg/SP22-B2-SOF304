package demo21test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import demo21.MathFunc;

public class TestMathFunc {
	MathFunc math;//tham chieu doi tuong MathFunc can test
	@Before
	public void init()//ham setup dung khoi tao doi tuong
	{
		math = new MathFunc();
	}
	@After
	public void teardown()
	{
		math=null;
	}
	@Ignore
	@Test
	public void todo()
	{
		assertTrue(math.plus(1, 1)==3);
	}
	@Test
	public void calls() throws Exception//kich ban test tuy y
	{
		assertEquals(0, math.getCalls());
		math.factorial(0);
		assertEquals(1, math.getCalls());
		math.factorial(1);
		assertEquals(2, math.getCalls());
		math.factorial(2);
		
	}
	@Test
	public void factorial() throws Exception//kich ban test tuy y
	{
		assertTrue(math.factorial(0)==1);
		assertTrue(math.factorial(1)==1);
		//assertTrue(math.factorial(5)==120);
		assertEquals(120, math.factorial(5));
	}
	@Test(expected = Exception.class)//kich ban test khi xay ra loi
	public void factorialNagative() throws Exception
	{
		math.factorial(-1);
	}
	
}
