﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using ConsoleApp1;

namespace TestProject1
{
    [TestFixture]
    public class TestCompare
    {
        [SetUp]
        public void Setup()
        { 
            
        }
        [Test]
        [Ignore("")]
        public void SoLonNhatTrong3So()
        {
            Assert.That(Compare.SoLonNhat(new int[] { 7, 9, 10 }), Is.EqualTo(10));
        }
        [Test]
        [Ignore("")]
        public void SoLonNhatTrong4So()
        {
            int[] arr = new int[4];
            arr[0] = 6;
            arr[1] = 8;
            arr[2] = -5;
            arr[3] = 100;
            Assert.That(Compare.SoLonNhat(arr), Is.EqualTo(100));
            //chu y: Assert con rat nhieu ham khac
            Assert.Less(1, 3);//nho hon
            Assert.Greater(1, 3);//lon hon
            Assert.GreaterOrEqual(1, 5);//lon hon bang
            Assert.LessOrEqual(1, 6); //nho hon bang
            Assert.IsNull(arr);//doi tuong la null
            Assert.IsNotNull(arr);//doi tuong khong null
            Assert.AreSame(arr, arr);//tham chieu den cung doi tuong
            Assert.IsTrue(true);
        }
        //chay nhieu test case trong 1 ham
        [TestCase(12,3,4)]
        [TestCase(12,2,6)]
        [TestCase(12,4,3)]
        public void TestPhepChia(int n, int d, int q)
        {
            Assert.AreEqual(q, n / d);
        }
        [Test,Order(1)]
        [TestCase(12, 4, 3)]
        public void TestPhepChia3(int n, int d, int q)
        {
            Assert.AreEqual(q, n / d);
        }
        [Test,Order(2)]
        [TestCase(12, 2, 6)]
        public void TestPhepChia2(int n, int d, int q)
        {
            Assert.AreEqual(q, n / d);
        }
        [Test,Order(3)]
        [TestCase(12, 4, 3)]
        public void TestPhepChia1(int n, int d, int q)
        {
            Assert.AreEqual(q, n / d);
        }
        [Test,MaxTime(2000)]
        [TestCase(12, 4, 3)]
        public void TestPhepChia4(int n, int d, int q)
        {
            Assert.AreEqual(q, n / d);
        }
    }
}
