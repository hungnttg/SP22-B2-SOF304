﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using ConsoleApp1;
namespace TestProject1
{
   [TestFixture]
    public class TestCalculator
    {
        private Calculator _cal;
        [SetUp]
        public void Setup()
        {
            _cal = new Calculator();//khoi tao doi tuong
        }
        [TearDown]
        public void Destroy()
        {
            _cal = null;
        }
        [Test]
        public void testHamCong_1()
        {
            Assert.AreEqual(4, _cal.Add(2, 2));
        }
        [Test]
        public void testHamCong_2()
        {
            Assert.AreEqual(2, _cal.Add(1, 1));
        }
        [Test]
        public void testHamCong_3()
        {
            Assert.AreEqual(5, _cal.Add(4, 1));
        }
        [Test]
        public void testHamTru_1()
        {
            Assert.AreEqual(1, _cal.Subtract(5, 4));
        }
    }
    [TestFixture]
    public class TestLop2
    {
        [Test]
        public void TestTrue()
        {
            Assert.IsTrue(true);
        }
        [Test]
        public void TestFault()
        {
            Assert.IsTrue(true);
        }
    }
    [TestFixture]
    public class TestLop3
    {
        [Test]
        public void TestTrueLop3()
        {
            Assert.IsTrue(true);
        }
        [Test]
        public void TestFaultLop3()
        {
            Assert.IsTrue(true);
        }
    }
}
