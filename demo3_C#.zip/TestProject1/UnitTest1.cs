using NUnit.Framework;
using System.IO;
using System;
using ConsoleApp1;
namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            //khoi tao cac doi tuong
        }
        [TearDown]
        public void Huy()
        { 
            //huy cac doi tuong
        }
        private const string Expected = "Hello World!";
        [Test]
        public void Test1()
        {
            //Assert.Pass();
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                ConsoleApp1.Program.Main();
                var result = sw.ToString().Trim();
                Assert.AreEqual(Expected, result);

            }
        }
    }
}