﻿using System;

namespace ConsoleApp1
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello World!");
        }
        public static void sayGoodbye()
        {
            Console.WriteLine("Goodbye!");
        }
    }
}
