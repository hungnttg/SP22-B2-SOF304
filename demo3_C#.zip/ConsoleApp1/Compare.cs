﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Compare
    {
        public static int SoLonNhat(int[] list)
        {
            int max = list[0];//khoi tao gia tri cho max
            for (int i=0; i <= list.Length-1;i++)
            {
                if (list[i] > max)
                {
                    max = list[i];
                }
            }
            return max;
        }
    }
}
