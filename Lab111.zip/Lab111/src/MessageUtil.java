
public class MessageUtil {
	private String message;
	
	public MessageUtil(String message)
	{
		this.message = message;
	}
	
	public String printMessage(String message)
	{
		System.out.println(message);
		return message;
	}

}
