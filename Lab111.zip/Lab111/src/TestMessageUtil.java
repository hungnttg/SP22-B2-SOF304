import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestMessageUtil {
	public String message = "Heelo world";
	MessageUtil demo = new MessageUtil(message);
	@Test
	public void testPrintMessage() {
		assertEquals(message, demo.printMessage(message));
		
	}

}
